var content = document.getElementsByClassName("content_swap");
var interaction = 0;
