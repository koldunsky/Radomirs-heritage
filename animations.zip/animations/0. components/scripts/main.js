function onLoad() {
  tab_initialization();
}

function tab_initialization() {
  tab_underscore(1);
  tab_underscore(2);
  tab_underscore(3);
}
